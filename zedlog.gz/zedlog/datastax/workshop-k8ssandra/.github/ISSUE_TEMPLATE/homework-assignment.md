---
name: Homework Assignment
about: Use this template to submit the homework
title: "[HW] <NAME>"
labels: homework
assignees: HadesArchitect

---

**Name:** <NAME>
**Linkedin Profile:** <LINK>

Attach the homework screenshots below:
-----------------------------------------

<SCREENSHOTS>
